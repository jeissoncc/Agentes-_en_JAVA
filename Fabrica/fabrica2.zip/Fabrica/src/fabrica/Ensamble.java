package fabrica;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.FSMBehaviour;

public class Ensamble extends Agent {

    class Receptor extends SimpleBehaviour {

        private boolean fin = false;

        public void action() {
            System.out.println(" Preparandose para recibir");

            //Obtiene el primer mensaje de la cola de mensajes
            ACLMessage mensaje = receive();

            if (mensaje != null) {
                System.out.println(getLocalName() + ": acaba de recibir el siguiente mensaje: ");
                System.out.println(mensaje.toString());
                fin = true;
            }
        }

        public boolean done() {
            return fin;
        }
    }

    public class MiAgente extends AgeATEnt {

        private static final String inicio = "uno";
        private static final String marco = "dos";
        private static final String llantas = "tres";
        private static final String frenos = "cuatro";
        private static final String fin = "cero";
        private final int UNO = 1;
        private final int DOS = 2;
        private final int TRES = 3;
        private final int CUATRO = 4;

        private final int CERO = 0;
        private String entrada = "";

        public void setup() {
            entrada = "231231231";
            MiFSMBehaviour b = new MiFSMBehaviour(this, entrada);
            addBehaviour(b);
        }

        private class MiFSMBehaviour extends FSMBehaviour {

            private int transicion = 0;
            private String entrada = "";

            public MiFSMBehaviour(Agent _agente, String ent) {
                super(_agente);
                entrada = ent;
            }

            public void onStart() {
                registerFirstState(new OneBehaviour(), inicio);
                registerState(new TwoBehaviour(), marco);
                registerState(new ThreeBehaviour(), llantas);
                registerState(new FourBehaviour(), frenos);
                registerState(new FinBehaviour(), fin);
                registerTransition(inicio, marco, DOS);
                registerTransition(TWO_STATE, THREE_STATE, TRES);
                registerTransition(THREE_STATE, ONE_STATE, UNO);
                registerDefaultTransition(ONE_STATE, ERROR_STATE);
                registerDefaultTransition(TWO_STATE, ERROR_STATE);
                registerDefaultTransition(THREE_STATE, ERROR_STATE);
            }

            protected boolean checkTermination(boolean currentDone, int currentResult) {
                System.out.println("Terminado " + currentName);
                return super.checkTermination(currentDone, currentResult);
            }

            public int getEntrada() {
                int tipoEvento = CERO;
                if (entrada.length() < 1) {
                    return tipoEvento;
                } else {
                    tipoEvento = Integer.parseInt(entrada.substring(0, 1));
                }
                entrada = entrada.substring(1, entrada.length());
                return tipoEvento;
            }

            private class OneBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println(" primer estado");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class TwoBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del segundo comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class ThreeBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del tercer comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }
            private class FourBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del cuarto comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class FinBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Fin");
                }
            }
        }
    }
}

class Entrega extends SimpleBehaviour {

    String nameAgent;

    public Entrega(String n) {
        nameAgent = n;
    }

    public void action() {

        doWait(20000);
        ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
        AID agrec = new AID(nameAgent, AID.ISLOCALNAME);
        acl.addReceiver(agrec);
        acl.setContent("Fabricacion Terminada");
        send(acl);
    }

    public boolean done() {
        return true;
    }

    protected void setup() {

        Object[] listaparametros = getArguments();
        String nameAgenteR = (String) listaparametros[0];

        System.out.println("Fabricacion Terminada");

        Entrega se = new Entrega(nameAgenteR);
        addBehaviour(se);
    }
}
}
