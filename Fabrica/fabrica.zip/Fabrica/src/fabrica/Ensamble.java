package fabrica;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

public class Ensamble extends Agent {

    class Receptor extends SimpleBehaviour {

        private boolean fin = false;

        public void action() {
            System.out.println(" Preparandose para recibir");

            //Obtiene el primer mensaje de la cola de mensajes
            ACLMessage mensaje = receive();

            if (mensaje != null) {
                System.out.println(getLocalName() + ": acaba de recibir el siguiente mensaje: ");
                System.out.println(mensaje.toString());
                fin = true;
            }
        }

        public boolean done() {
            return fin;
        }
    }

    protected void setup() {
        addBehaviour(new Receptor());
    }

    public class FSM {
        int[] input = {1, 2, 3, 4};
        int inicio = 1;
        int finalizar = 4;
        int actual = inicio+1;        
        boolean fin = false;
        int contador = 1;
        
        {
            while(fin == false)
        {
            if (contador == input.length){
                fin = true;
                  break;
            }
            if (actual == 1) {
                if (input[contador] == 1) {
                    actual = actual+1;
                    System.out.println("Ensamble de Marco");
                }
                contador++;
                continue;
            }
            if (actual == 2) {
                if (input[contador] == 2) {
                    actual = actual+1;
                    System.out.println("Ensamble de Llantas");
                }
                contador++;
                continue;
            }
            if (actual == 3) {
                if (input[contador] == 3) {
                    actual = actual+1;
                    System.out.println("Ensamble de frenos");
                }
                contador++;
                continue;
            }
            
             if (actual == 4) {
                if (input[contador] == 4) {
                    actual = actual+1;
                    System.out.println("Ensamble cambios");
                }
                contador++;
                continue;
            }
        if(actual==finalizar)
       {
            System.out.println("Ensamble Finalizado");
            break;
        }
      }
    }
   }
    
    class Entrega extends SimpleBehaviour {
    String nameAgent;
    
    public Entrega (String n) {nameAgent = n;}
    public void action(){
        
        doWait(20000);
        ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
        AID agrec = new AID(nameAgent, AID.ISLOCALNAME);
        acl.addReceiver(agrec);
        acl.setContent("Fabricacion Terminada");
        send (acl);      
    }
    
    public boolean done(){
        return true;
    }

protected void setup(){
    
    Object[] listaparametros = getArguments();
    String nameAgenteR = (String) listaparametros[0];
    
    System.out.println("Fabricacion Terminada");
    
    Entrega se = new Entrega(nameAgenteR);
    addBehaviour(se);
    }   
  }
}
