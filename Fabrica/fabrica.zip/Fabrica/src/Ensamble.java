
import jade.core.*;
import jade.core.behaviours.*;
import jade.core.lang.acl.*;


public class Ensamble extends Agent {

    
}
