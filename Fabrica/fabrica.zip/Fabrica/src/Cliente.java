

import jade.core.*;
import jade.core.behaviours.*;
import jade.core.lang.acl.*;
import jade.lang.acl.ACLMessage;


public class Cliente extends Agent{
    
    class Enviar extends SimpleBehaviour{
        
        String nameAgent;
        
        public Enviar (String n) {nameAgent = n;}
        public void action(){
            
            doWait(20000);
            ACLMessage acl = new ACLMessage (ACLMessage.REQUEST);
            AID agrec = new AID(nameAgent, AID.ISLOCALNAME);
            acl.addReceiver(agrec);
            acl.setContent("Iniciar Ensamble");
            send(acl);
        }
        
        public boolean done(){
            return true;
        }
        
    }
    
    protected void setup(){
        Object [] listaparametros = getArguments();
        String nameAgentR = (String) listaparametros[0];
        
        Enviar ce = new Enviar(nameAgentR);
        addBehaviour(ce);
    }
    
}
