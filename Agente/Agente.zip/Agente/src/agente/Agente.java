package agente;
import jade.core.Agent;

public class Agente extends Agent{
       public void setup(){
            System.out.println("Hola");
        }
    }
